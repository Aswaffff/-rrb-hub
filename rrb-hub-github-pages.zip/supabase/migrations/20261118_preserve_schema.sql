-- Safe, Non-Destructive Schema Inspection & Column Check for Supabase Project: dujgqwzxxmpdsikhkhbk
-- 1. Does NOT drop, recreate, or overwrite public."Payment" or public."Telegram".
-- 2. Checks information_schema.columns first and adds `delivery_status` ONLY if it does not already exist.

DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM information_schema.tables
    WHERE table_schema = 'public' AND table_name = 'Payment'
  ) THEN
    IF NOT EXISTS (
      SELECT 1
      FROM information_schema.columns
      WHERE table_schema = 'public'
        AND table_name = 'Payment'
        AND column_name = 'delivery_status'
    ) THEN
      ALTER TABLE public."Payment"
        ADD COLUMN delivery_status text NOT NULL DEFAULT 'Awaiting Manual Delivery';
    END IF;
  END IF;
END $$;

-- Ensure Row Level Security remains enabled on both existing tables
ALTER TABLE IF EXISTS public."Payment" ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS public."Telegram" ENABLE ROW LEVEL SECURITY;
