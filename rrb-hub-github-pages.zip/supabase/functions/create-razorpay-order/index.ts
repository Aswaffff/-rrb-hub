// Supabase Edge Function: create-razorpay-order
// Project: https://dujgqwzxxmpdsikhkhbk.supabase.co
// Strictly uses server-only RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET. Never exposes secret key to browser.

import { serve } from "https://deno.land/std@0.192.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const ALLOWED_PLANS = new Set(["Malayalam PDF", "English PDF", "Hindi PDF"]);
const FIXED_AMOUNT_PAISE = 15100; // ₹151.00 INR

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const keyId = Deno.env.get("RAZORPAY_KEY_ID");
    const keySecret = Deno.env.get("RAZORPAY_KEY_SECRET");

    if (!keyId || !keySecret) {
      return new Response(
        JSON.stringify({ error: "Server Razorpay credentials are not configured yet." }),
        { status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const body = await req.json();
    const fullName = String(body.full_name || "").trim();
    const email = String(body.email || "").trim().toLowerCase();
    const rawMobile = String(body.mobile_number || "").replace(/\D/g, "").slice(-10);
    const plan = String(body.plan || "").trim();

    if (fullName.length < 2) {
      return new Response(JSON.stringify({ error: "Invalid customer name." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return new Response(JSON.stringify({ error: "Invalid customer email." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (!/^[6-9]\d{9}$/.test(rawMobile)) {
      return new Response(JSON.stringify({ error: "Invalid 10-digit Indian mobile number." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (!ALLOWED_PLANS.has(plan)) {
      return new Response(JSON.stringify({ error: "Invalid study material language plan." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const mobileNormalized = `+91${rawMobile}`;
    const receiptId = `rrbhub_${Date.now()}_${rawMobile.slice(-4)}`;

    const basicAuth = btoa(`${keyId}:${keySecret}`);
    const rzpResp = await fetch("https://api.razorpay.com/v1/orders", {
      method: "POST",
      headers: {
        "Authorization": `Basic ${basicAuth}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        amount: FIXED_AMOUNT_PAISE,
        currency: "INR",
        receipt: receiptId,
        notes: {
          full_name: fullName,
          email: email,
          mobile_number: mobileNormalized,
          plan: plan,
        },
      }),
    });

    if (!rzpResp.ok) {
      const errText = await rzpResp.text();
      return new Response(JSON.stringify({ error: "Failed to create Razorpay order", details: errText }), {
        status: 502,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const orderData = await rzpResp.json();
    return new Response(
      JSON.stringify({
        order_id: orderData.id,
        amount: FIXED_AMOUNT_PAISE,
        currency: "INR",
        key_id: keyId,
        plan: plan,
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
