// Supabase Edge Function: payment-status
// Project: https://dujgqwzxxmpdsikhkhbk.supabase.co
// 1. Queries private public."Payment" table using server-only SUPABASE_SERVICE_ROLE_KEY.
// 2. Returns "verified" when Status === "success" | "PAID", amount_paise === 15100, and currency === "INR".
// 3. Returns ONLY minimal state (verified | pending | failed) — never exposes customer PII or Telegram links.

import { serve } from "https://deno.land/std@0.192.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.7";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") || "https://dujgqwzxxmpdsikhkhbk.supabase.co";
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || Deno.env.get("SUPABASE_SECRET_KEYS");

    if (!serviceRoleKey) {
      return new Response(JSON.stringify({ status: "pending", message: "Server verification key not configured" }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { razorpay_order_id, razorpay_payment_id } = await req.json();
    if (!razorpay_order_id && !razorpay_payment_id) {
      return new Response(JSON.stringify({ status: "failed", error: "Missing order or payment ID" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(supabaseUrl, serviceRoleKey);
    let query = supabase
      .from("Payment")
      .select("Status, amount_paise, currency, razorpay_order_id, razorpay_payment_id")
      .limit(1);

    if (razorpay_payment_id) {
      query = query.eq("razorpay_payment_id", razorpay_payment_id);
    } else {
      query = query.eq("razorpay_order_id", razorpay_order_id);
    }

    const { data, error } = await query;
    if (error || !data || data.length === 0) {
      return new Response(JSON.stringify({ status: "pending" }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const row = data[0];
    const rawStatus = String(row.Status || "").toLowerCase();
    const isVerified =
      (rawStatus === "success" || rawStatus === "paid") &&
      Number(row.amount_paise) === 15100 &&
      row.currency === "INR";

    return new Response(
      JSON.stringify({ status: isVerified ? "verified" : "failed" }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(JSON.stringify({ status: "pending" }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
