// Supabase Edge Function: admin-orders
// Verifies authenticated admin user via Supabase Auth JWT (must match ADMIN_EMAIL / rrbhub@gmail.com)
// Allows listing verified orders from public."Payment" and updating manual PDF delivery status.

import { serve } from "https://deno.land/std@0.192.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.7";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, POST, PATCH, OPTIONS",
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") || "https://dujgqwzxxmpdsikhkhbk.supabase.co";
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || Deno.env.get("SUPABASE_SECRET_KEYS");
    const allowedAdminEmail = (Deno.env.get("ADMIN_EMAIL") || "rrbhub@gmail.com").toLowerCase();

    if (!serviceRoleKey) {
      return new Response(JSON.stringify({ error: "Missing server configuration" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const authHeader = req.headers.get("Authorization") || "";
    const token = authHeader.replace("Bearer ", "").trim();
    const supabase = createClient(supabaseUrl, serviceRoleKey);

    const { data: userData, error: userErr } = await supabase.auth.getUser(token);
    if (userErr || !userData?.user || userData.user.email?.toLowerCase() !== allowedAdminEmail) {
      return new Response(JSON.stringify({ error: "Unauthorized: Admin access required" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (req.method === "GET") {
      const { data: orders, error } = await supabase
        .from("Payment")
        .select("*")
        .order("verified_at", { ascending: false });

      if (error) throw error;
      return new Response(JSON.stringify({ orders }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (req.method === "PATCH" || req.method === "POST") {
      const body = await req.json();
      const { razorpay_payment_id, delivery_status } = body;
      if (!razorpay_payment_id || !["Awaiting Manual Delivery", "Delivered Manually"].includes(delivery_status)) {
        return new Response(JSON.stringify({ error: "Invalid parameters" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const { data: updated, error } = await supabase
        .from("Payment")
        .update({ delivery_status })
        .eq("razorpay_payment_id", razorpay_payment_id)
        .eq("Status", "success")
        .select()
        .single();

      if (error) throw error;
      return new Response(JSON.stringify({ order: updated }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response("Method Not Allowed", { status: 405, headers: corsHeaders });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
