// Supabase Edge Function: razorpay-webhook
// Endpoint: https://dujgqwzxxmpdsikhkhbk.supabase.co/functions/v1/razorpay-webhook
// Verifies X-Razorpay-Signature using HMAC-SHA256 on raw request body with server-only RAZORPAY_WEBHOOK_SECRET.
// Processes payment.captured for ₹151 (15100 paise INR) and inserts/upserts verified order into public."Payment".

import { serve } from "https://deno.land/std@0.192.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.7";

async function verifyRazorpayWebhookSignature(
  rawBody: string,
  signatureHex: string,
  webhookSecret: string
): Promise<boolean> {
  const encoder = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw",
    encoder.encode(webhookSecret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sigBuffer = await crypto.subtle.sign("HMAC", key, encoder.encode(rawBody));
  const computedHex = Array.from(new Uint8Array(sigBuffer))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");

  if (computedHex.length !== signatureHex.length) return false;
  let diff = 0;
  for (let i = 0; i < computedHex.length; i++) {
    diff |= computedHex.charCodeAt(i) ^ signatureHex.charCodeAt(i);
  }
  return diff === 0;
}

serve(async (req: Request) => {
  if (req.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405 });
  }

  try {
    const webhookSecret = Deno.env.get("RAZORPAY_WEBHOOK_SECRET");
    const supabaseUrl = Deno.env.get("SUPABASE_URL") || "https://dujgqwzxxmpdsikhkhbk.supabase.co";
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || Deno.env.get("SUPABASE_SECRET_KEYS");

    if (!webhookSecret || !serviceRoleKey) {
      return new Response("Server secrets not configured", { status: 500 });
    }

    const signature = req.headers.get("x-razorpay-signature") || "";
    const rawBody = await req.text();

    const isValid = await verifyRazorpayWebhookSignature(rawBody, signature, webhookSecret);
    if (!isValid) {
      return new Response("Invalid webhook signature", { status: 401 });
    }

    const payload = JSON.parse(rawBody);
    if (payload.event !== "payment.captured") {
      return new Response(JSON.stringify({ received: true, ignored_event: payload.event }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      });
    }

    const payment = payload?.payload?.payment?.entity;
    if (!payment || Number(payment.amount) !== 15100 || payment.currency !== "INR") {
      return new Response("Invalid payment amount or currency", { status: 400 });
    }

    const notes = payment.notes || {};
    const fullName = String(notes.full_name || notes.name || "Customer").trim();
    const email = String(notes.email || payment.email || "").trim().toLowerCase();
    const mobileNumber = String(notes.mobile_number || notes.mobile || payment.contact || "").trim();
    const plan = String(notes.plan || notes.language || "Malayalam PDF").trim();

    const supabase = createClient(supabaseUrl, serviceRoleKey);

    // Optional lookup from public."Telegram" table if used by owner
    let linkValue: string | null = null;
    const { data: tgRow } = await supabase
      .from("Telegram")
      .select('"Telegram link"')
      .eq("Plan name", plan)
      .maybeSingle();
    if (tgRow && tgRow["Telegram link"]) {
      linkValue = tgRow["Telegram link"];
    }

    // Idempotent upsert into public."Payment" on razorpay_payment_id
    const { error: upsertErr } = await supabase
      .from("Payment")
      .upsert(
        {
          "Email": email,
          "Plan": plan,
          "Status": "success",
          "Links": linkValue,
          "Full Name": fullName,
          "Mobile Number": mobileNumber,
          razorpay_payment_id: payment.id,
          razorpay_order_id: payment.order_id,
          amount_paise: 15100,
          currency: "INR",
          delivery_status: "Awaiting Manual Delivery",
          verified_at: new Date().toISOString(),
        },
        { onConflict: "razorpay_payment_id" }
      );

    if (upsertErr) {
      return new Response(JSON.stringify({ error: upsertErr.message }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ status: "ok", verified_payment_id: payment.id }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
});
